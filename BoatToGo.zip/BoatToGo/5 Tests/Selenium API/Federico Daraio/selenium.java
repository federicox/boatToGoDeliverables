package testselenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class selenium
{

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/Boat-To-Go-Final/index.jsp");
		
		driver.findElement(By.xpath("//*[@id=\"enddate\"]")).click();;
		driver.findElement(By.xpath("/html/body/div[5]/div[1]/div[2]/table/tbody/tr[2]/td[4]/div")).click();
		
		WebElement TxtBoxContent = driver.findElement(By.xpath("//*[@id=\"enddate\"]"));
		
		System.out.println("printing"+ TxtBoxContent.getAttribute("value"));
		driver.close();
	}
}